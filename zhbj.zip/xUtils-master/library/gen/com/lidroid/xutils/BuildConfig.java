/** Automatically generated file. DO NOT MODIFY */
package com.lidroid.xutils;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}